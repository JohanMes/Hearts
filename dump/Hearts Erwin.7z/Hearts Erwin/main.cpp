#include <ctime>
#include <cstdlib>
#include <iostream>
#include <iomanip>

#include "hearts.h"
#include "default_player.h"
#include "jcmes.h"
#include "douwe.h"

using namespace std;

int main() {
	// Hearts simulator
	Hearts h = Hearts();
//	
//	// Hearts players
//	h.setPlayer(new DefaultPlayer(), 0);
//	h.setPlayer(new DefaultPlayer(), 1);
//	h.setPlayer(new DefaultPlayer(), 2);
//	h.setPlayer(new DefaultPlayer(), 3);
//	
//	h.playGame();
//	
//	cout << h << endl;
	
	int score1  = 0;
	int wins1	= 0;
	int score2  = 0;
	int wins2	= 0;
	int score3  = 0;
	int wins3	= 0;
	int score4  = 0;
	int wins4	= 0;
	
	for(int i=0; i<1000; i++)
	{
		Player *player1 = new DefaultPlayer();
		Player *player2 = new DefaultPlayer();
		Player *player3 = new jcmes();
		Player *player4 = new Douwe();
		
		h.setPlayer(player1, 0);
		h.setPlayer(player2, 1);
		h.setPlayer(player3, 2);
		h.setPlayer(player4, 3);
		
		h.playGame();
		
		vector<int> score;
		score.clear();
		
		score.push_back(player1->getScore());
		score.push_back(player2->getScore());
		score.push_back(player3->getScore());
		score.push_back(player4->getScore());
		
		int minscore = 200;		
		int minwinner = -1; 
		
		for(int j=0; j<4; j++)
		{
			if(minscore > score[j])
			{
				minscore = score[j];
				minwinner = j;
			}
		}
		switch(minwinner)
		{
			case 0:
				wins1 += 1;
				break;
			case 1:
				wins2 += 1;
				break;
			case 2:
				wins3 += 1;
				break;
			case 3:
				wins4 += 1;
				break;
			case -1:
				cout << "that is strange";
				break;
		}
		
		score1 += score[0];
		score2 += score[1];
		score3 += score[2];
		score4 += score[3];
		
		//cout << endl;
		//cout << h << endl;
		//Sleep(10000);	
	}
	
	cout << "Hartenjagen-bot tester  |  1000 potjes" << endl << endl;
	cout << "\t\tPunten" << "\t" << "Gewonnen" << endl;
	cout << "\t\t(gem.)" << "\t" << "(aantal)" << endl;
	cout << endl;
	cout << "DefaultPlayer:\t " << fixed << setprecision(1) << score1/1000.0 << " \t " << wins1 << endl;
	cout << "DefaultPlayer:\t " << score2/1000.0 << " \t " << wins2 << endl;
	cout << "DefaultPlayer:\t " << score3/1000.0 << " \t " << wins3 << endl;
	cout << "Douwe:        \t " << score4/1000.0 << "\t " << wins4 << endl;

	cin.ignore();
		
	return 0;
}
