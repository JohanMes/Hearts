#include <iostream>

#include "card.h"

using namespace std;

//*********************************************************************************
// Color functions
//*********************************************************************************

Color operator++(Color &color, int) {
	#ifdef DEBUG
	clog << "LOG: Color::operator++" << endl;
	clog << "LOG: Oude waarde van color: " << color << " (" << ((int) color) << ")" << endl;
	#endif
	
	color = (Color) ((int) color + 1);
	
	#ifdef DEBUG
	clog << "LOG: Nieuwe waarde van color: " << color << " (" << ((int) color) << ")" << endl;
	#endif
	
	return color;
}

ostream &operator<<(ostream &out, Color color) {
	switch (color) {
		case COLOR_CLUBS:
			out << "clubs";
			break;
		case COLOR_SPADES:
			out << "spades";
			break;
		case COLOR_DIAMONDS:
			out << "diamonds";
			break;
		case COLOR_HEARTS:
			out << "hearts";
			break;
	}
	
	return out;
}

//*********************************************************************************
// Value functions
//*********************************************************************************

Value operator++(Value &value, int) {
	#ifdef DEBUG
	clog << "LOG: Value::operator++" << endl;
	clog << "LOG: Oude waarde van value: " << value << " (" << ((int) value) << ")" << endl;
	#endif
	
	value = (Value) ((int) value + 1);
	
	#ifdef DEBUG
	clog << "LOG: Nieuwe waarde van value: " << value << " (" << ((int) value) << ")" << endl;
	#endif
	
	return value;
}

ostream &operator<<(ostream &out, Value value) {
	switch (value) {
		case VALUE_TWO:
			out << "two";
			break;
		case VALUE_THREE:
			out << "three";
			break;
		case VALUE_FOUR:
			out << "four";
			break;
		case VALUE_FIVE:
			out << "five";
			break;
		case VALUE_SIX:
			out << "six";
			break;
		case VALUE_SEVEN:
			out << "seven";
			break;
		case VALUE_EIGHT:
			out << "eight";
			break;
		case VALUE_NINE:
			out << "nine";
			break;
		case VALUE_TEN:
			out << "ten";
			break;
		case VALUE_JACK:
			out << "jack";
			break;
		case VALUE_QUEEN:
			out << "queen";
			break;
		case VALUE_KING:
			out << "king";
			break;
		case VALUE_ACE:
			out << "ace";
			break;
	}
	
	return out;
}

//*********************************************************************************
// Card class and functions
//*********************************************************************************

Card::Card() {
	d_color = COLOR_CLUBS;
	d_value = VALUE_TWO;
	d_penalty = 0.;
	
	#ifdef DEBUG
	clog << "LOG: Nieuwe kaart aangemaakt (clubs, 2, 0.)." << endl;
	#endif
}

Card::Card(Color color, Value value, double penalty) {
	d_color = color;
	d_value = value;
	d_penalty = penalty;
	
	#ifdef DEBUG
	clog << "LOG: Nieuwe kaart aangemaakt (" << d_color << ", " << d_value << ", " << d_penalty << ")." << endl;
	#endif
}

Color Card::color() {
	return d_color;
}

Value Card::value() {
	return d_value;
}

double Card::penalty() {
	return d_penalty;
}

void Card::setColor(Color color) {
	#ifdef DEBUG
	clog << "LOG: Kaart (" << d_color << ", " << d_value << ", " << d_penalty << ") krijgt een nieuwe kleur (" << color << ")." << endl;
	#endif
	
	d_color = color;
}

void Card::setValue(Value value) {
	#ifdef DEBUG
	clog << "LOG: Kaart (" << d_color << ", " << d_value << ", " << d_penalty << ") krijgt een nieuwe waarde (" << value << ")." << endl;
	#endif
	
	d_value = value;
}

void Card::setPenalty(double penalty) {
	#ifdef DEBUG
	clog << "LOG: Kaart (" << d_color << ", " << d_value << ", " << d_penalty << ") krijgt een nieuwe penalty (" << penalty << ")." << endl;
	#endif
	
	d_penalty = penalty;
}

ostream &operator<<(ostream &out, Card card) {
	out << card.value() << " of " << card.color() << ": " << card.penalty() << endl;
	
	return out;
}
