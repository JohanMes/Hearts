#include <ctime>
#include <cstdlib>
#include <iostream>
#include <iostream>
#include <string.h>
#include <windows.h>
#include <sstream>

#include "douwe.h"

Douwe::Douwe()
{
    d_score = 0;
    q_gespeeld = 0;
}

void Douwe::setPlayerId(int my_number)
{
	d_player_id = my_number;
}

int Douwe::receiveCards(vector<Card *> * kaarten)
{
	// decide wheter to shoot the moon or not...
    // Check if many of one color (e.g. >7)
    // or many high hearts and Q and high spades

    // At least! harten aas!
	
	for(unsigned int i = 0;i < kaarten->size();i++) 
	{
			//cout << (*kaarten)[i] << endl;
	}
	//Sleep(5000);
	
	if(kaarten != NULL)
	{
		//Sleep(2000);
		//cout << "______________________________________________________" << endl << endl; 
		// Bijhouden van scores resetten!
		score.clear();
		score.push_back(1);
	    score.push_back(1);
	    score.push_back(1);
	    score.push_back(1);
	    
	    // Bijhouden van gespeelde kaarten initialiseren
	    gespeeld.clear();
	    for(int j=0; j<4; j++)
	    {
			vector<int> s;
			for(int i=0; i<13; i++)
	    	{
				s.push_back(0);	
	    	}
	   		gespeeld.push_back(s);
		}	
	
		// Spelvariabelen init
	    have_queen  = false;
	    q_gespeeld  = false;
	    first_trick = true;
	    
	    // Speler zonder kaarten van een kleur op nul zetten
	    out_of.clear();
	    out_of.push_back(0);
	    out_of.push_back(0);
	    out_of.push_back(0);
	    out_of.push_back(0);
	    
	    // Hand met kaarten aanmaken
	    d_hand.clear();	    
	    for(unsigned int j=0;j < (*kaarten).size(); j++)
	    {
	       d_hand.push_back(kaarten->at(j));
	    }
	}
    return 0;
}

std::vector<Card *> * Douwe::passThreeCards(void)
{
	if(d_hand.size() < 1)
		return 0;
	
	// eerst hoge schoppen weggeven
	// queen houden als meer dan 4 schoppen, anders weg
	// Harten een waarde geven van (value-1) * 2) (>10 eerst spelen). 
	// --------------------------------------------------
	// Kijken hoeveel kaarten van bepaalde kleur in hand!
	
	
	/// WEGhalen --> als veel van de zelfde kaart -> juist houden en andere kleur weggeven!
	
	vector<int> num_hand;
	num_hand.clear();
	num_hand.push_back(0);
	num_hand.push_back(0);
	num_hand.push_back(0);
	num_hand.push_back(0);

	for(unsigned int j=0; j<d_hand.size(); j++)
	{
		num_hand[(int)d_hand[j]->color()] += 1;
	}		
	
	for(unsigned int j=0; j<num_hand.size(); j++)
	{
		if(num_hand[j] > 8)
		{
			//cout << "kleur " << j << ", aantal " << num_hand[j] << endl; 
		}
	}
	
	
	// controleer of ik de koningin heb!
    for(unsigned int i = 0;i < d_hand.size();i++) 
	{
		if((int)d_hand[i]->value() == 12 && (int) d_hand[i]->color() == 1 )
		{
			have_queen = true;
		}
	}

    Card *card;
    vector<Card *> * kaarten_weg = new vector<Card *>;

    for(int i=0; i<3; i++)
    {
		int highest  = 0;
        int location = -1;

        for(int j=0; unsigned(j) < d_hand.size(); j++)
        {
            int value = d_hand[j]->value();
            int color = d_hand[j]->color();
            int compare = value;

			if(color == 3)
            {
                compare = (compare-1)*2;    // Harten zijn best vervelend
            }
            if(color == 1 && value > 11 && num_hand[1] <= 4)
            {
                compare += 30;     			// Schoppen kaarten boven queen zijn gevaarlijk!
                if(value == 12)
                {
                    compare += 30; 			// Schoppen queen weg!
                }
            }
            if(num_hand[1] == 5 && color == 1 && have_queen)
            {
            	value = 1;
            }
            
//            if(num_hand[color] > 5) // Gevaarlijk om 6 of meer van dezelfde kleur te hebben!
//            {
//            	value += 10;
//            }

            if(compare > highest || (compare == highest && num_hand[color] > num_hand[(int)d_hand[location]->color()]))
            {
                card     = d_hand[j];
                location = j;
                highest  = compare;
            }
        }
        if(location == -1)
        	cout << "ERROR . in passThreeCards()\n";
        kaarten_weg->push_back(card);
        d_hand.erase(d_hand.begin() + location);
    }
    
//  for(unsigned int i = 0;i < kaarten_weg->size();i++) 
//	{
//		cout << (int)(*kaarten_weg)[i]->value() << "\t" << (*kaarten_weg)[i]->color() << endl;
//	}
//	cout << endl;
    
    return kaarten_weg;
}

int Douwe::receiveThreeCards(std::vector<Card *> * kaarten_terug)
{
	if(kaarten_terug != NULL)
	{
		hearts_broken = 0;
		
	    d_hand.push_back((*kaarten_terug)[0]);
	    d_hand.push_back((*kaarten_terug)[1]);
	    d_hand.push_back((*kaarten_terug)[2]);
	    
	    //cout << "Hand: " << endl;
	    for(unsigned int i = 0;i < d_hand.size();i++) 
		{
			//cout << (Card) *d_hand[i];
			if((int)d_hand[i]->value() == 12 && (int) d_hand[i]->color() == 1 )
			{
				have_queen = true;
				//cout << " ######## QUEEN #########";
			}
		//	Sleep(5000);
		//	cout << endl;
		}
	}
    return 0;
}

// If true --> I start, else another player starts
bool Douwe::hasTwoOfClubs()
{
    if(d_hand.size() < 1)
    	return 0;
	
	for(unsigned int i=0; i < d_hand.size(); i++)
    {
        if( (int)(*d_hand[i]).value() == 2 && (int)(*d_hand[i]).color() == 0)
        {
            return 1;
        }
    }
    return 0;
}

void Douwe::playCard(Trick * slag)
{
	if(slag == NULL) // Controleer of de pointer wel bestaat!
		return;
		
	nummer_in_ronde = slag->cards().size();

//	cout << endl;
//    for(int i=0; i < slag->cards().size(); i++)
//    {
//		cout << (int) slag->cards()[i]->value() << " " << slag->cards()[i]->color() << ", ";
//    }
//    cout << endl;
// ==============================================
	
	// Als klavertwee, speel die!
    for(unsigned int i=0; i < d_hand.size(); i++)
    {
        int color = d_hand[i]->color();
        int value = d_hand[i]->value();

        if(value == 2 && color == 0)
        {
            slag->addCard(d_hand[i]);
            //cout << d_hand[i]->value() << " " << d_hand[i]->color() << " Douwe added a card 5" << endl;
            //cout << "Speel 1: " << d_hand[i]->value() << " " << d_hand[i]->color() << endl;
			d_hand.erase(d_hand.begin() + i);
            return;
        }
    }
    
    // Opslaan hoeveel kaarten er van een kleur gespeeld zijn!
    vector<int> num_played;
    num_played.clear();
	num_played.push_back(0);
	num_played.push_back(0);
	num_played.push_back(0);
	num_played.push_back(0);
	
	for(int i=0; i<4; i++)
	{
		for(int j=0; j<13; j++)
    	{
    		if(gespeeld[i][j] == 1)
    		{
				num_played[i] += 1;
    		}
    	}
	}
	
	// Voeg hierbij ook de kaarten die al op tafel liggen!
	for(unsigned int i=0; i < slag->cards().size(); i++)
    {
		num_played[(int) slag->cards()[i]->color()] += 1;
    }
	
	// Sla aantal kaarten van ��n kleur in hand op!
	vector<int> num_hand;
	num_hand.push_back(0);
	num_hand.push_back(0);
	num_hand.push_back(0);
	num_hand.push_back(0);

	for(unsigned int j=0; j<d_hand.size(); j++)
	{
		num_hand[(int)d_hand[j]->color()] += 1;
	}	
	
	// Eerste ronde ... Speel hoge kaart want geen punten!
	// Geen kaart met punten spelen!!!
	if(first_trick)
	{
		// Eerst kleurbekennen! --> hoogste
		int index = -1;
		int hoogste = 0;			
		for(unsigned int i=0; i<d_hand.size(); i++)
        {
            int color = d_hand[i]->color();
            int value = d_hand[i]->value();
            
			if(color == 1 && value == 12)
            {
            	value = 1;
            }
            
            if(color == (int)slag->color() && value > hoogste)
            {
                index   = i;
                hoogste = d_hand[i]->value();
            }
        }
        if(index != -1)
        {
        	slag->addCard(d_hand[index]);   
			//cout << d_hand[index]->value() << " " << d_hand[index]->color() << " Douwe added a card 6" << endl;     
        	//cout << "Speel 0a: " << d_hand[index]->value() << " " << d_hand[index]->color() << endl;
			d_hand.erase(d_hand.begin() + index);	        
        	return;
        }
    	
    	// Als kleurbekennen niet kan --> speel slechtste kaart!
    	int highest = 0;
        int location = -1;
        for(unsigned int i=0; i<d_hand.size(); i++)
        {
            int value = d_hand[i]->value();
            int color = d_hand[i]->color();
			int compare = value;
			
			if(color == 3)
            {
                compare = 1;    			// Harten mogen niet!
            }
            if(color == 1 && value > 11)
            {
                compare += 30;     			// Schoppen kaarten boven queen zijn gevaarlijk!
                if(value == 12)
                {
                    compare = 1; 			// Schoppen queen mag niet
                }
            }

            if(compare > highest || (compare > (highest - 2) && num_hand[color] > num_hand[d_hand[location]->color()]))
            {
                location = i;
                highest  = compare;
            }
        }
        if(location == -1)
        	cout << "ERROR . around line 300\n";
        slag->addCard(d_hand[location]);
        //cout << d_hand[location]->value() << " " << d_hand[location]->color() << " Douwe added a card 7" << endl;
        //cout << "Speel 0b: " << d_hand[location]->value() << " " << d_hand[location]->color() << endl;
		d_hand.erase(d_hand.begin() + location);	        
        return;
	}
    
	// Als er nog geen kaarten gespeeld zijn in slag
    // Speel dan laagste kaart
    if(slag->cards().size() == 0)
    {
    	// Bereken offset per kleur
		vector<int> color_offset;
		color_offset.clear();
		color_offset.push_back(offset(0));
		color_offset.push_back(offset(1));
		color_offset.push_back(offset(2));
		color_offset.push_back(offset(3));
    	
        int lowest_card = -1;
        int best_value = 250;
        for(unsigned int i=0; i<d_hand.size(); i++)
        {
            int value = d_hand[i]->value();
            int color = d_hand[i]->color();
			
			if(!hearts_broken && color == 3)
				value += 160;
							
			if(color == 1 && value == 12)
				value += 150;
			
			if(color == 1 && value > 12 && !have_queen && !q_gespeeld)
				value += 120;
				
			if(value - color_offset[color] == 2)
				value = 1;

			if(color == 1 && have_queen)
				value += 5;

			value += 15*out_of[color];

			if(num_played[color] > 11)
			{
				value = 100;
				color_offset[color] = 0;
			}
			
			if(value < best_value || ( value == best_value && num_played[color] < num_played[d_hand[lowest_card]->color()]))
			{
				lowest_card = i;
                best_value = d_hand[i]->value();
			}
        }
		if(lowest_card == -1)
			cout << "ERROR . around line 330\n";
        slag->addCard(d_hand[lowest_card]);
		// cout << d_hand[lowest_card]->value() << " " << d_hand[lowest_card]->color() << " Douwe added a card 8" << endl;
        //cout << "Speel 2: " << d_hand[lowest_card]->value() << " " << d_hand[lowest_card]->color() << endl;

		d_hand.erase(d_hand.begin() + lowest_card);		
		return;
    }

    // Kijk of er niet al 3 kaarten liggen zonder penalty
    // Zoja, speel dan een tactische kaart
    if(slag->cards().size() == 3)
    {
        if(slag->penalty() == 0) // speel hoogste kaart (die geen punten kost)
        {
        	// Eerst kleurbekennen! --> hoogste
			int index = -1;
			int hoogste = 0;			
			for(unsigned int i=0; i<d_hand.size(); i++)
            {
                int color = d_hand[i]->color();
                int value = d_hand[i]->value();
                
				if(color == 1 && value == 12)
                {
                	value = 1;
                }
                
                if(color == (int)slag->color() && value > hoogste)
                {
                    index   = i;
                    hoogste = d_hand[i]->value();
                }
            }
            if(index != -1)
            {
            	slag->addCard(d_hand[index]);
	        	//cout << d_hand[index]->value() << " " << d_hand[index]->color() << " Douwe added a card 9" << endl;
	        	//cout << "Speel 3a: " << d_hand[index]->value() << " " << d_hand[index]->color() << endl;

				d_hand.erase(d_hand.begin() + index);	        
	        	return;
            }
        	
        	// Als kleurbekennen niet kan --> speel slechtste kaart!
        	int highest = 0;
	        int location = -1;
	        for(unsigned int i=0; i<d_hand.size(); i++)
	        {
	            int value = d_hand[i]->value();
	            int color = d_hand[i]->color();
				int compare = value;
				
				if(color == 3)
	            {
	                compare = (compare-1)*2;    // Harten zijn best vervelend
	            }
	            if(color == 1 && value > 11)
	            {
	                compare += 30;     			// Schoppen kaarten boven queen zijn gevaarlijk!
	                if(value == 12)
	                {
	                    compare += 30; 			// Schoppen queen weg!
	                }
	            }
	
	            if(compare > highest || (compare == highest && num_played[color] > num_played[(int)d_hand[location]->color()]))
	            {
	                location = i;
	                highest  = compare;
	            }
	        }
	        if(location == -1)
	        	cout << "ERROR . around line 400\n";
	        slag->addCard(d_hand[location]);
	        //cout << d_hand[location]->value() << " " << d_hand[location]->color() << " Douwe added a card 10" << endl;
	        //cout << "Speel 3b: " << d_hand[location]->value() << " " << d_hand[location]->color() << endl;

			d_hand.erase(d_hand.begin() + location);	        
	        return;
        }
    	else if(slag->penalty() > 4)	// Q zit erin! --> niet nemen
    	{
			// Hoogste kaart van slag herleiden:
			int highest_trickcard = 0;
			for(unsigned int i=0; i < slag->cards().size(); i++)            // zolang er nog kaarten niet bekeken zijn
		    {
		        if((int) slag->cards()[i]->color() == (int)slag->color()) 	// Als kleur hetzelfde is
		        {
		            if(slag->cards()[i]->value() > highest_trickcard)       // Waarde hoger dan highest_kaart?
		            {
		                highest_trickcard = slag->cards()[i]->value();      // highest_trickcard -> nieuwe hoge waarde
		            }
		        }
		    }
		    
		    // kleur bekennen
			int hoogste = 0;
            int index = -1;
            for(unsigned int i=0; i<d_hand.size(); i++)
            {
                int color = d_hand[i]->color();
                int value = d_hand[i]->value();
                
                if(value > hoogste && value < highest_trickcard && color == (int)slag->color())
                {
                    index   = i;
                    hoogste = d_hand[i]->value();
                }
            }
            if(index > -1)
            {
            	slag->addCard(d_hand[index]);
            	
            	//cout << "Speel 4: " << d_hand[index]->value() << " " << d_hand[index]->color() << endl;
            	
				d_hand.erase(d_hand.begin() + index);
				return;
            }
            // kijken naar hogere kaarten van slagkleur
            for(unsigned int i=0; i<d_hand.size(); i++)
            {
                int color = d_hand[i]->color();
                int value = d_hand[i]->value();
                
                if(value > hoogste && color == (int)slag->color())
                {
                    index   = i;
                    hoogste = d_hand[i]->value();
                }
            }
            if(index > -1)
            {
            	slag->addCard(d_hand[index]);
            	//cout << d_hand[index]->value() << " " << d_hand[index]->color() << " Douwe added a card 11" << endl;
            	//cout << "Speel 5: " << d_hand[index]->value() << " " << d_hand[index]->color() << endl;
            	
				d_hand.erase(d_hand.begin() + index);
				return;
            }
            
            // Geen kaarten van slagkleur --> dus lekker hoog kaartje!
			int highest  = 0;
	        int location = 0;
	
	        for(unsigned int j=0; j < d_hand.size(); j++)
	        {
	            int value = d_hand[j]->value();
	            int color = d_hand[j]->color();
	            int compare = value;
	            if(color == 3)
	            {
	                compare = (compare*2);      // Harten zijn best vervelend
	            }
	
	            if(compare > highest)
	            {
	                location = j;
	                highest  = compare;
	            }
	        }
	        if(location == -1)
	        	cout << "ERROR . around line 490\n";
	        slag->addCard(d_hand[location]);
	        //cout << d_hand[location]->value() << " " << d_hand[location]->color() << " Douwe added a card 12" << endl;
	        //cout << "Speel 6: " << d_hand[location]->value() << " " << d_hand[location]->color() << endl;
	        
			d_hand.erase(d_hand.begin() + location);
			return;
    	}
    	else if(slag->penalty() == 1) 	// niet zo erg. Neem deze als er 3 mensen zonder punten zijn!
    	{
    		int mooning = 0;
    		for(int i=0; i<4; i++)
    		{
    			if(score[i] == 0)
    			{
    				mooning += 1;
    			}
    		}
    		if(mooning == 3)
    		{
    			// zorg dat je de hand krijgt!
    			int hoogste = 0;
	            int index = -1;
	            for(unsigned int i=0; i<d_hand.size(); i++)
	            {
	                int color = d_hand[i]->color();
	                int value = d_hand[i]->value();
	                
	                if(value == 12 && color == 1)
	                {
	                	value = 1;
	                }
	                
	                if(value > hoogste && color == (int)slag->color())
	                {
	                    index   = i;
	                    hoogste = d_hand[i]->value();
	                }
	            }
	            if(index > 0)
	            {
	            	slag->addCard(d_hand[index]);
	            	//cout << d_hand[index]->value() << " " << d_hand[index]->color() << " Douwe added a card 13" << endl;
	            	//cout << "Speel 7: " << d_hand[index]->value() << " " << d_hand[index]->color() << endl;
	            	
					d_hand.erase(d_hand.begin() + index);
					return;
	            }    			
    		}
    	}
    	// Speel hoogste kaart wanneer kleurbekennen niet hoeft!
    	
    	// Vind de hoogste kaart van slagkleur op tafel
	    int highest_trickcard = 0;
	    for(unsigned int i=0; i < slag->cards().size(); i++)            // zolang er nog kaarten niet bekeken zijn
	    {
	        if((int) slag->cards()[i]->color() == (int)slag->color()) // Als kleur hetzelfde is
	        {
	            if(slag->cards()[i]->value() > highest_trickcard)       // Waarde hoger dan highest_kaart?
	            {
	                highest_trickcard = slag->cards()[i]->value();      // highest_trickcard -> nieuwe hoge waarde
	            }
	        }
	    }
	
	    // Kies de hoogste waarde van trickkleur onder highest_trickcard
	    int best_card  = -1;
	    int best_value = -1;
	    for(unsigned int i=0; i < d_hand.size(); i++)
	    {
	        int value = d_hand[i]->value();
	        int color = d_hand[i]->color();
	
	        if(color == (int)slag->color())
	        {
	            if(value < highest_trickcard)
	            {
	                if(value > best_value)
	                {
	                    best_card  = i;
	                    best_value = value;
	                }
	            }
	        }
	    }
	
	    // Als die niet bestaat kies hoogste kaart van trickkleur
	    int higher_card = -1;
	        best_value  = 15;
	    if(best_card != -1)     // Speel die kaart
	    {
	        slag->addCard(d_hand[best_card]);
	        //cout << d_hand[best_card]->value() << " " << d_hand[best_card]->color() << " Douwe added a card 14" << endl;
	        //cout << "Speel 8: " << d_hand[best_card]->value() << " " << d_hand[best_card]->color() << endl;
			
			d_hand.erase(d_hand.begin() + best_card);
			return;
	    }
	    else                    // Geen lage, speel hoogste!
	    {
	        for(unsigned int i=0; i < d_hand.size(); i++)
	        {
	            int color = d_hand[i]->color();
	            int value = d_hand[i]->value();
				
	            if(color == (int)slag->color())
	            {
	                if(value > best_value)
	                {
	                    higher_card = i;
	                    best_value = value;
	                }
	            }
	        }
	    }
	    
	    if(higher_card != -1)   // speel die kaart
	    {
	        slag->addCard(d_hand[higher_card]);
	        //cout << d_hand[higher_card]->value() << " " << d_hand[higher_card]->color() << " Douwe added a card 15" << endl;
	        //cout << "Speel 9: " << d_hand[higher_card]->value() << " " << d_hand[higher_card]->color() << endl;
	        
			d_hand.erase(d_hand.begin() + higher_card);
			return;
	    }
	    else                    // Speel slechtste kaart!
	    {
	        int highest  = 0;
	        int location = 0;
	
	        for(unsigned int j=0; j < d_hand.size(); j++)
	        {
	            int value = d_hand[j]->value();
	            int color = d_hand[j]->color();
	            int compare = value;
	            if(color == 3)
	            {
	            	if(value > 10)
	            	{
	            		compare = compare*2;      // Harten zijn best vervelend
					}
					else
					{
						compare = compare + 2;
					}                
	            }
			
	            if(color == 1 && value > 11 && !q_gespeeld) // Als queen nog niet gespeeld
	            {
	                compare += 30;     // Schoppen kaarten boven queen zijn gevaarlijk!
	                if(value == 12)
	                {
	                    compare += 30; // Schoppen queen weg!
	                }
	            }
	            if(color == 1 && value > 5 && value < 12 && !q_gespeeld)  // Bewaar een schoppen zolang de queen in het spel is
				{
					value = 5;
				}
	            if(compare > highest)
	            {
	                location = j;
	                highest  = compare;
	            }
	        }
	        if(location == -1)
	        	cout << "ERROR . around line 650\n";
	        slag->addCard(d_hand[location]);
	        //cout << d_hand[location]->value() << " " << d_hand[location]->color() << " Douwe added a card 16" << endl;
	        //cout << "Speel 10: " << d_hand[location]->value() << " " << d_hand[location]->color() << endl;
			
			d_hand.erase(d_hand.begin() + location);
			return;
		}
	}

    // Vind de hoogste kaart van slagkleur op tafel
    int highest_trickcard = 0;
    for(unsigned int i=0; i < slag->cards().size(); i++)            // zolang er nog kaarten niet bekeken zijn
    {
        if((int) slag->cards()[i]->color() == (int)(*slag).color()) // Als kleur hetzelfde is
        {
            if(slag->cards()[i]->value() > highest_trickcard)       // Waarde hoger dan highest_kaart?
            {
                highest_trickcard = slag->cards()[i]->value();      // highest_trickcard -> nieuwe hoge waarde
            }
        }
    }

    // Kies de hoogste waarde van trickkleur onder highest_trickcard
    int best_card  = -1;
    int best_value = -1;
    for(unsigned int i=0; i < d_hand.size(); i++)
    {
        int value = d_hand[i]->value();
        int color = d_hand[i]->color();

        if(color == (int)slag->color())
        {
            if(value < highest_trickcard)
            {
                if(value > best_value)
                {
                    best_card  = i;
                    best_value = value;
                }
            }
        }
    }

    // Als die niet bestaat kies laagste kaart boven highest_trickcard
    int higher_card = -1;
        best_value  = 15;
    if(best_card != -1)     // Speel die kaart
    {
        slag->addCard(d_hand[best_card]);
       	//cout << d_hand[best_card]->value() << " " << d_hand[best_card]->color() << " Douwe added a card 17" << endl;
        //cout << "Speel 11: " << d_hand[best_card]->value() << " " << d_hand[best_card]->color() << endl;
        
		d_hand.erase(d_hand.begin() + best_card);
		return;
    }
    else                    // Geen lage, speel hogere kaart van trickkleur
    {
        for(unsigned int i=0; i < d_hand.size(); i++)
        {
            int color = d_hand[i]->color();
            int value = d_hand[i]->value();
			
			if(color == 1 && value == 12)
			{
				value = 15;
			}		
			
            if(color == (int)slag->color())
            {
                if(value < best_value)
                {
                    higher_card = i;
                    best_value = value;
                }
            }
        }
    }

    // Als kleurbekennen niet kan, kies kaart met meeste punten
    if(higher_card != -1)   // speel die kaart
    {
        slag->addCard(d_hand[higher_card]);
        //cout << d_hand[higher_card]->value() << " " << d_hand[higher_card]->color() << " Douwe added a card 19" << endl;
        //cout << "Speel 12: " << d_hand[higher_card]->value() << " " << d_hand[higher_card]->color() << endl;
		
		d_hand.erase(d_hand.begin() + higher_card);
		return;
    }
    else                    // Speel slechtste kaart!
    {
        int highest  = 0;
        int location = 0;

        for(unsigned int j=0; j < d_hand.size(); j++)
        {
            int value = d_hand[j]->value();
            int color = d_hand[j]->color();
            int compare = value;
            if(color == 3)
            {
            	if(value > 10)
            	{
            		compare = compare*2;      // Harten zijn best vervelend
				}
				else
				{
					compare = compare + 2;
				}                
            }
            if(color == 1 && value > 11 && !q_gespeeld && !have_queen) // Als queen nog niet gespeeld
            {
                compare += 30;     // Schoppen kaarten boven queen zijn gevaarlijk!
                if(value == 12)
                {
                    compare += 30; // Schoppen queen weg!
                }
            }
            if(color == 1 && value > 3 && value < 9 && !q_gespeeld && !have_queen) // Bewaar schoppen als queen nog in spel is!
            {
            	value = 3;
            }

            if(compare > highest)
            {
                location = j;
                highest  = compare;
            }
        }
        if(location == -1)
        	cout << "ERROR . around 770\n";
        slag->addCard(d_hand[location]); 
        //cout << d_hand[location]->value() << " " << d_hand[location]->color() << " Douwe added a card 20" << endl;
		//cout << "Speel 13: " << d_hand[location]->value() << " " << d_hand[location]->color() << endl;

		d_hand.erase(d_hand.begin() + location);
		return;
    }
    return;
}

void Douwe::storeTrick(Trick * hele_slag)
{
	//Sleep(5000);
	if(hele_slag)
	{
		//cout << "===== Winning player: " << hele_slag->winningPlayer() << endl;
		//cout << "===== First player: " << hele_slag->startPlayer() << endl;
	    if(hele_slag->winningPlayer() == nummer_in_ronde)
	    {
	        d_score += hele_slag->penalty();
			
			if(hele_slag->penalty() > 0)
			{
				//cout << "******************* Penalty: " << hele_slag->penalty() << " ******************* Speler: " << hele_slag->winningPlayer() << endl; 
				for(int i=0; i< hele_slag->cards().size(); i++)
				{
					//cout << (int)hele_slag->cards()[i]->value() << " " << hele_slag->cards()[i]->color() << ", ";
				}
				//cout << endl << endl;
				//Sleep(8000);
			}
			if(hele_slag->penalty() == 26)
			{
				//cout << "Douwe shot the moon!" << endl;
			}
	    }
	    for(int i=0; i<hele_slag->cards().size(); i++)	// Sla op welke kaarten al gespeeld zijn!
	  	{
	  		int color = hele_slag->cards()[i]->color();
	  		int value = hele_slag->cards()[i]->value();
	  		if(color == 1 && value == 12)
	  		{
	  			q_gespeeld = 1;
	  		}
	  		if(color == 3 && !hearts_broken)
	  		{
	  			hearts_broken = true;
	  		}
	  		gespeeld[color][value-2] = 1;
	  		
	  		if(color != (int)hele_slag->color())
	  		{
	  			out_of[color] = 2;
	  		}
	  	}
	  	if(hele_slag->cards().size() != 4)
	  	{
	  		cout << "DAT IS GEK! Aantal kaarten in de slag is " << hele_slag->cards().size() << endl;
			for(int i=0; i< hele_slag->cards().size(); i++)
				{
					cout << (int)hele_slag->cards()[i]->value() << " " << hele_slag->cards()[i]->color() << ", ";
				}
				cout << endl;
			Sleep(5000);
		}
	  	else
	  		cout << "\n";
	  	
	  	
	    // Bewaar de score van tegenstanders (in dit potje)
	    //score[hele_slag->winningPlayer()] += hele_slag->penalty();
	    first_trick = false;
	}
}
	
int Douwe::getScore()
{
	//cout << "\nTotal score = " << d_score << endl;
    return d_score;
}

int Douwe::offset(int color)
{
	// Tel gespeelde kaarten vanaf 2 tot er een "gat" komt in de rij
	int offset_count = 0;
	
	for(int i=0; i<13; i++) // De waarde van gespeeld (j) is gelijk aan waarde-2
	{
		offset_count += gespeeld[color][i];
		//cout << "(" << i << ") ";
		if(gespeeld[color][i] == 0 || i>=12)
		{
		//	cout << " == " << offset_count << "\n";
			return offset_count;
		}
	}	
	return 0;
}





