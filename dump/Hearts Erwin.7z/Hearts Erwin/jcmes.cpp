#include <algorithm>
#include <iostream>
#include <queue>

#include "jcmes.h"

void jcmes::setPlayerId(int id) {
	d_player_id = id;
}

int jcmes::receiveCards(std::vector<Card*>* stapel) {
	
	// Krijgen we geen imaginaire stapel?
	if(stapel) {
		
		// Vervang de kaarten (hand zou leeg moeten zijn, maar toch)
		hand.clear();
		for(unsigned int i = 0;i < stapel->size();i++) {
			hand.push_back(stapel->at(i));
		}
	}
	return 0; // ???
}

std::vector<Card*>* jcmes::passThreeCards(void) {
	
	//////std::cout << "Current hand (" << hand.size() << " cards):\n";
	for(unsigned int i = 0;i < hand.size();i++) {
		PrintKaart(hand[i]);
	}
	
	// We beginnen opnieuw
	heartsbroken = false;
	playedcards.clear();
	
	int givencount = 0;
	
	//////std::cout << "\n\nPassing three cards...\n";
	
	// Pass de eerste drie kaarten
	std::vector<Card*>* passhand = new std::vector<Card*>;
	
	//////std::cout << "Giving spades cards higher than queen...\n";
	
	// Pass spades hoger than queen
	for(unsigned int i = VALUE_ACE;i > VALUE_QUEEN;i--) {
		int index = FindValueColor(&hand,(value)i,COLOR_SPADES);
		if(index != -1) {
			givencount += ExchangeCard(passhand,&hand,index);
			if(givencount == 3) {
				return passhand;
			}
		}
	}
	
	int sqindex = FindValueColor(&hand,VALUE_QUEEN,COLOR_SPADES);
	if(sqindex != -1) {
		
		int spadecount = CountColorBelowValue(&hand,VALUE_QUEEN,COLOR_SPADES);
		
		//////std::cout << "We have " << spadecount << " spade cards below queen...\n";
		
		if(spadecount >= 4) {
			//////std::cout << "Keeping queen of spades...\n";
		} else {
			//////std::cout << "Giving queen of spades...\n";
			givencount += ExchangeCard(passhand,&hand,sqindex);
			if(givencount == 3) {
				return passhand;
			}
		}
	}

	//////std::cout << "Giving hearts above 10...\n";
	
	for(unsigned int i = VALUE_ACE;i > VALUE_TEN;i--) {
		int index = FindValueColor(&hand,(value)i,COLOR_HEARTS);
		if(index != -1) {
			givencount += ExchangeCard(passhand,&hand,index);
			if(givencount == 3) {
				return passhand;
			}
		}
	}
	
	// Probeer deze kaart kwijt te raken, want dan kunnen we zelf bepalen wat we opgooien in de 1ste ronde
	
	//////std::cout << "Giving two of clubs...\n";
	
	givencount += ExchangeCard(passhand,&hand,FindValueColor(&hand,VALUE_TWO,COLOR_CLUBS));
	if(givencount == 3) {
		return passhand;
	}
	
	if(3 - givencount >= CountColor(&hand,COLOR_DIAMONDS)) {
		
		//////std::cout << "Giving all diamond cards...\n";
		for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
			int index = FindValueColor(&hand,(value)i,COLOR_DIAMONDS);
			if(index != -1) { // keep the queen if we still have it here
				givencount += ExchangeCard(passhand,&hand,index);
				if(givencount == 3) {
					return passhand;
				}
			}
		}
	}
	
	if(3 - givencount >= CountColor(&hand,COLOR_CLUBS)) {
		
		//////std::cout << "Giving all clubs cards...\n";
		for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
			int index = FindValueColor(&hand,(value)i,COLOR_CLUBS);
			if(index != -1) { // keep the queen if we still have it here
				givencount += ExchangeCard(passhand,&hand,index);
				if(givencount == 3) {
					return passhand;
				}
			}
		}
	}
	
	//////std::cout << "Giving other highest possible cards...\n";
	
	for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
		int index = FindFirstValue(&hand,(value)i);
		if(index != -1 and index != sqindex) { // keep the queen if we still have it here
			givencount += ExchangeCard(passhand,&hand,index);
			if(givencount == 3) {
				return passhand;
			}
		}
	}

	return passhand;
}

int jcmes::receiveThreeCards(std::vector<Card*>* passhand) {
	
	//////std::cout << "\n\nReceived the following cards...\n";
	
	for(unsigned int i = 0;i < passhand->size();i++) {
		PrintKaart(passhand->at(i));
		hand.push_back(passhand->at(i));
	}

	Next(true);
	return 0; // ???
}

bool jcmes::hasTwoOfClubs(void) {
	beginwithtwoofclubs = (FindValueColor(&hand,VALUE_TWO,COLOR_CLUBS) != -1);
	return beginwithtwoofclubs;
}

void jcmes::playCard(Trick* stapel) {
	if(stapel) {
		
		std::vector<Card*> cards = stapel->cards();
		
		//////std::cout << "Current hand (" << hand.size() << " cards):\n";
		for(unsigned int i = 0;i < hand.size();i++) {
			PrintKaart(hand[i]);
		}
		
		playedcardindex = cards.size();
		
		PreferColor tempstruct;
		
		if(cards.size() == 0) {
			
			//////std::cout << "\n\nStarting pile...\n";
			
			// Uitzondering: we moeten beginnen met klaver twee
			if(beginwithtwoofclubs) {
				
				//////std::cout << "Passing two of clubs...\n";
				
				MoveIndexToStapel(stapel,&hand,FindValueColor(&hand,VALUE_TWO,COLOR_CLUBS));
				
				beginwithtwoofclubs = false;
				
				return;
			}
			
			// Niet controleren op eerste ronde (en dan zo hoog mogelijk): als we beginnen, moeten we altijd 2 van clubs spelen
			
			int enemydiamondcount = 13 - CountColor(&playedcards,COLOR_DIAMONDS) - CountColor(&hand,COLOR_DIAMONDS);
			int enemyclubcount = 13 - CountColor(&playedcards,COLOR_CLUBS) - CountColor(&hand,COLOR_CLUBS);
			int enemyspadescount = 13 - CountColor(&playedcards,COLOR_SPADES) - CountColor(&hand,COLOR_SPADES);
			int enemyheartscount = 13 - CountColor(&playedcards,COLOR_HEARTS) - CountColor(&hand,COLOR_HEARTS);
			
			//////std::cout << "Number of diamond cards still to play is " << enemydiamondcount << "...\n";
			//////std::cout << "Number of club cards still to play is " << enemyclubcount << "...\n";
			//////std::cout << "Number of spades cards still to play is " << enemyspadescount << "...\n";
			//////std::cout << "Number of hearts cards still to play is " << enemyheartscount << "...\n";
			
			int lowestdiamond = GetMinValueOfColor(&hand,COLOR_DIAMONDS);
			int lowestclub = GetMinValueOfColor(&hand,COLOR_CLUBS);
			int lowestspades = GetMinValueOfColor(&hand,COLOR_SPADES);
			int lowesthearts = GetMinValueOfColor(&hand,COLOR_HEARTS);

			//////std::cout << "Lowest diamond value is " << lowestdiamond << "...\n";
			//////std::cout << "Lowest club value is " << lowestclub << "...\n";
			//////std::cout << "Lowest spades value is " << lowestspades << "...\n";
			//////std::cout << "Lowest hearts value is " << lowesthearts << "...\n";
			
			int sqindex1 = FindValueColor(&hand,VALUE_QUEEN,COLOR_SPADES);
			int sqindex2 = FindValueColor(&playedcards,VALUE_QUEEN,COLOR_SPADES);
			if(sqindex1 != -1) {
				
				//////std::cout << "We have the queen of spades...\n";
				
				if(!heartsbroken) {
					
					//////std::cout << "Hearts are not yet broken...\n";
					
					//////std::cout << "Opening with diamonds or clubs...\n";
					
					tempstruct.thiscolor = COLOR_DIAMONDS;
					tempstruct.enemycount = enemydiamondcount;
					tempstruct.lowestvalue = lowestdiamond;
					colorlist.push(tempstruct);
					
					tempstruct.thiscolor = COLOR_CLUBS;
					tempstruct.enemycount = enemyclubcount;
					tempstruct.lowestvalue = lowestclub;
					colorlist.push(tempstruct);
					
					if(ProcessFirstCardPriority(stapel)) {
						return;
					}
					
					//////std::cout << "Don't have diamonds or clubs, playing spades cards above queen...\n";
					
					for(unsigned int i = VALUE_ACE;i > VALUE_QUEEN;i--) {
						int index = FindValueColor(&hand,(value)i,COLOR_SPADES);
						if(index != -1) {
							
							//////std::cout << "Passing lowest allowed card...\n";
				
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
					
					//////std::cout << "Playing spades cards below queen...\n";
					
					for(unsigned int i = VALUE_TWO;i < VALUE_QUEEN;i++) {
						int index = FindValueColor(&hand,(value)i,COLOR_SPADES);
						if(index != -1) {
							
							//////std::cout << "Passing lowest allowed card...\n";
				
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
					
					//////std::cout << "Don't have diamonds or clubs or other spades, have to pass queen of spades...\n";
					
					if(MoveIndexToStapel(stapel,&hand,sqindex1)) {// jammer hoor
						return;
					}
					
					//////std::cout << "Opening with any hearts card (against rules)...\n";
					
					if(PassLowestColor(stapel,COLOR_HEARTS)) {
						return;
					}
				} else { // hearts wel broken
				
					//////std::cout << "Hearts are broken...\n";
					
					//////std::cout << "Opening with diamonds or clubs...\n";
					
					tempstruct.thiscolor = COLOR_DIAMONDS;
					tempstruct.enemycount = enemydiamondcount;
					tempstruct.lowestvalue = lowestdiamond;
					colorlist.push(tempstruct);
					
					tempstruct.thiscolor = COLOR_CLUBS;
					tempstruct.enemycount = enemyclubcount;
					tempstruct.lowestvalue = lowestclub;
					colorlist.push(tempstruct);
					
					if(lowesthearts < 5) { // Probeer punten te ontwijken
					
						//////std::cout << "Also considering hearts, cards have low enough value...\n";
					
						tempstruct.thiscolor = COLOR_HEARTS;
						tempstruct.enemycount = enemyheartscount;
						tempstruct.lowestvalue = lowesthearts;
						colorlist.push(tempstruct);
					}
					
					if(ProcessFirstCardPriority(stapel)) {
						return;
					}
						
					//////std::cout << "Don't have diamonds or clubs (or hearts), playing spades cards above queen...\n";
					
					for(unsigned int i = VALUE_ACE;i > VALUE_QUEEN;i--) {
						int index = FindValueColor(&hand,(value)i,COLOR_SPADES);
						if(index != -1) {
							
							//////std::cout << "Passing lowest allowed card...\n";
				
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
					
					//////std::cout << "Playing spades cards below queen...\n";
					
					for(unsigned int i = VALUE_TWO;i < VALUE_QUEEN;i++) {
						int index = FindValueColor(&hand,(value)i,COLOR_SPADES);
						if(index != -1) {
							
							//////std::cout << "Passing lowest allowed card...\n";
				
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
					
					//////std::cout << "Opening with any hearts card...\n";
					
					if(PassLowestColor(stapel,COLOR_HEARTS)) {
						return;
					}
					
					//////std::cout << "Don't have diamonds or clubs or other spades, have to pass queen of spades...\n";
					
					if(MoveIndexToStapel(stapel,&hand,sqindex1)) {// jammer hoor
						return;
					}
				} // end of heartsbroken
			} else { // we hebben geen queen of spades
			
				//////std::cout << "We don't have the queen of spades...\n";
				
				if(!heartsbroken) {
					
					//////std::cout << "Hearts are not yet broken...\n";
					
					//////std::cout << "Opening with diamonds, clubs or spades...\n";
					
					tempstruct.thiscolor = COLOR_DIAMONDS;
					tempstruct.enemycount = enemydiamondcount;
					tempstruct.lowestvalue = lowestdiamond;
					colorlist.push(tempstruct);
					
					tempstruct.thiscolor = COLOR_CLUBS;
					tempstruct.enemycount = enemyclubcount;
					tempstruct.lowestvalue = lowestclub;
					colorlist.push(tempstruct);
					
					if(sqindex2 != -1) { // hij ligt op de playedcards-stapel
						//////std::cout << "Queen of spades already played...\n";
						
						//////std::cout << "Considering opening with spades...\n";
						
						tempstruct.thiscolor = COLOR_SPADES;
						tempstruct.enemycount = enemyspadescount;
						tempstruct.lowestvalue = lowestspades;
						colorlist.push(tempstruct);
						
					} else {
						
						//////std::cout << "Queen of spades not yet played...\n";
					
						if(lowestspades < VALUE_QUEEN) {

							//////std::cout << "Considering opening with spades below queen...\n";
							
							tempstruct.thiscolor = COLOR_SPADES;
							tempstruct.enemycount = enemyspadescount;
							tempstruct.lowestvalue = lowestspades;
							colorlist.push(tempstruct);
						}
					}
					
					if(ProcessFirstCardPriority(stapel)) {
						return;
					}
					
					//////std::cout << "Don't have diamonds or clubs (or spades), playing spades cards...\n";
					
					if(PassLowestColor(stapel,COLOR_SPADES)) {
						return;
					}

					//////std::cout << "Opening with any hearts card (against rules)...\n";
				
					if(PassLowestColor(stapel,COLOR_HEARTS)) {
						return;
					}
				} else { // hearts wel broken, bitch is nog ergens anders
				
					//////std::cout << "Hearts are broken...\n";
				
					//////std::cout << "Opening with diamonds, clubs or spades...\n";
					
					tempstruct.thiscolor = COLOR_DIAMONDS;
					tempstruct.enemycount = enemydiamondcount;
					tempstruct.lowestvalue = lowestdiamond;
					colorlist.push(tempstruct);
					
					tempstruct.thiscolor = COLOR_CLUBS;
					tempstruct.enemycount = enemyclubcount;
					tempstruct.lowestvalue = lowestclub;
					colorlist.push(tempstruct);
					
					if(sqindex2 != -1) { // hij ligt op de playedcards-stapel
						//////std::cout << "Queen of spades already played...\n";
						
						//////std::cout << "Considering opening with spades...\n";
						
						tempstruct.thiscolor = COLOR_SPADES;
						tempstruct.enemycount = enemyspadescount;
						tempstruct.lowestvalue = lowestspades;
						colorlist.push(tempstruct);
						
					} else {
						
						//////std::cout << "Queen of spades not yet played...\n";
					
						if(lowestspades < VALUE_QUEEN) {

							//////std::cout << "Considering opening with spades below queen...\n";
							
							tempstruct.thiscolor = COLOR_SPADES;
							tempstruct.enemycount = enemyspadescount;
							tempstruct.lowestvalue = lowestspades;
							colorlist.push(tempstruct);
						}
					}
					
					if(lowesthearts < 5) { // Probeer punten te ontwijken
					
						//////std::cout << "Also considering hearts, cards have low enough value...\n";
					
						tempstruct.thiscolor = COLOR_HEARTS;
						tempstruct.enemycount = enemyheartscount;
						tempstruct.lowestvalue = lowesthearts;
						colorlist.push(tempstruct);
					}
					
					if(ProcessFirstCardPriority(stapel)) {
						return;
					}
					
					//////std::cout << "Don't have diamonds or clubs (or spades or hearts), playing spades cards...\n";
					
					if(PassLowestColor(stapel,COLOR_SPADES)) {
						return;
					}
				
					//////std::cout << "Opening with any hearts card (last option)...\n";
				
					if(PassLowestColor(stapel,COLOR_HEARTS)) {
						return;
					}
				} // end of heartsbroken
			} // end of queen spades
		} else { // end of starting pile
		
			//////std::cout << "\n\nCurrent pile (" << stapel->penalty() << " points):\n";
			for(unsigned int i = 0;i < cards.size();i++) {
				PrintKaart(cards.at(i));
			}
			
			int validplayindex = FindFirstColor(&hand,stapel->color());
			
			// We moeten kleur volgen :(
			if(validplayindex != -1) {
				
				//////std::cout << "Following starting color (" << stapel->color() << ")...\n";
				
				// Uitzondering: eerste ronde zo hoog mogelijk troep meegeven, maar GEEN punten
				if(hand.size() == 13) {
					
					int sqindex = FindValueColor(&hand,VALUE_QUEEN,COLOR_SPADES);
					
					//////std::cout << "Following pile of first round...\n";
					
					for(unsigned int i = VALUE_ACE;i > VALUE_TWO;i--) {
						int index = FindValueColor(&hand,(value)i,stapel->color());
						if(index != -1 && index != sqindex) {
							//////std::cout << "Passing highest possible zero points card...\n";
						
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
				}

				// Er ligt wat spul van waarde op de stapel, probeer te omzeilen
				if(stapel->penalty() > 0) {
					
					//////std::cout << "Trying to avoid penalties (" << stapel->penalty() << ")...\n";
					
					// Geef altijd van de huidige kleur de kaart weg die lager is dan de huidige hoogste kaart
					Value maxstapelvalue = GetMaxValueOfColor(&cards,stapel->color());
					for(unsigned int i = maxstapelvalue-1;i >= VALUE_TWO;i--) {
						int index = FindValueColor(&hand,(value)i,stapel->color());
						if(index != -1) {
							
							//////std::cout << "Avoided penalty using highest possible card below current max...\n";
							
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
					
					// Hebben we die zalige kaarten niet gevonden? Geef hoger mee
					for(unsigned int i = maxstapelvalue+1;i <= VALUE_ACE;i++) {
						int index = FindValueColor(&hand,(value)i,stapel->color());
						if(index != -1) {
							
							//////std::cout << "Taken penalty using higher card than pile...\n";
							
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
				
				// Stapel is tot nu toe waardeloos...
				} else {
					
					//////std::cout << "Don't have to avoid penalties...\n";
					
					if(cards.size() == 3) {
						
						//////std::cout << "Passing last card of pile...\n";
						
						if(stapel->color() == COLOR_SPADES) {
							
							//////std::cout << "Avoiding queen of spades...\n";
							
							// Geef van de huidige kleur de zo hoog mogelijke kaart weg, niet queen of spades
							for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
								
								int index = FindValueColor(&hand,(value)i,stapel->color());
								if(index != -1 && i != VALUE_QUEEN) {
									
									//////std::cout << "Passing highest allowed card (not queen)...\n";
									
									MoveIndexToStapel(stapel,&hand,index);
									return;
								}
							}
							
							//////std::cout << "Can't avoid queen of spades...\n";
							
							// Als we hier komen, hebben we alleen een queen of spades :(
							int sqindex = FindValueColor(&hand,VALUE_QUEEN,COLOR_SPADES);
							if(sqindex != -1) {
								
								//////std::cout << "Passing queen of spades...\n";
								
								MoveIndexToStapel(stapel,&hand,sqindex);
							}
						} else {
							
							//////std::cout << "Don't have to avoid queen of spades...\n";
							
							// Geef van de huidige kleur de zo hoog mogelijke kaart weg
							for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
								int index = FindValueColor(&hand,(value)i,stapel->color());
								if(index != -1) {
									
									//////std::cout << "Passing highest allowed card...\n";
									
									MoveIndexToStapel(stapel,&hand,index);
									return;
								}
							}
						}
					} else {
						
						// Of gooi dan de laagst mogelijke kaart weg van goeie kleur
						
						int enemycolorcount = 13 - CountColor(&playedcards,stapel->color()) - CountColor(&hand,stapel->color());
						
						//////std::cout << "Number of pile color cards still to play is " << enemycolorcount << "...\n";
						
						if((enemycolorcount > 3 and cards.size() == 2) or (enemycolorcount > 6 and cards.size() == 1)) {
							
							//////std::cout << "Assuming noone will play penalty cards...\n";
						
							if(stapel->color() == COLOR_SPADES) {
								for(unsigned int i = VALUE_QUEEN-1;i >= VALUE_TWO;i--) {
									int index = FindValueColor(&hand,(value)i,stapel->color());
									if(index != -1) {
										
										//////std::cout << "Passing highest possible card below queen of spades...\n";
										
										MoveIndexToStapel(stapel,&hand,index);
										return;
									}
								}
								
								//////std::cout << "Passing higher than queen of spades...\n";
								for(unsigned int i = VALUE_QUEEN+1;i <= VALUE_ACE;i++) {
									int index = FindValueColor(&hand,(value)i,stapel->color());
									if(index != -1) {
										
										//////std::cout << "Passing card higher than queen...\n";
										
										MoveIndexToStapel(stapel,&hand,index);
										return;
									}
								}
								
								//////std::cout << "Passing queen of spades...\n";
								MoveIndexToStapel(stapel,&hand,FindValueColor(&hand,VALUE_QUEEN,stapel->color()));
							} else {
								for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
									int index = FindValueColor(&hand,(value)i,stapel->color());
									if(index != -1) {
										
										//////std::cout << "Passing highest possible card...\n";
										
										MoveIndexToStapel(stapel,&hand,index);
										return;
									}
								}
							}
						} else {
							
							//////std::cout << "Assuming someone will play penalty cards...\n";
							
							for(unsigned int i = GetMaxValueOfColor(&cards,stapel->color())-1;i >= VALUE_TWO;i--) {
								int index = FindValueColor(&hand,(value)i,stapel->color());
								if(index != -1) {
									
									//////std::cout << "Passing highest possible card below current max...\n";
									
									MoveIndexToStapel(stapel,&hand,index);
									return;
								}
							}
							
							for(unsigned int i = GetMaxValueOfColor(&cards,stapel->color())+1;i <= VALUE_ACE;i++) {
								int index = FindValueColor(&hand,(value)i,stapel->color());
								if(index != -1) {
									
									//////std::cout << "Passing lowest possible card above current max...\n";
									
									MoveIndexToStapel(stapel,&hand,index);
									return;
								}
							}
						}
					}
				}
			} else {
				
				//////std::cout << "Not following starting color...\n";
				
				int sqindex = FindValueColor(&hand,VALUE_QUEEN,COLOR_SPADES);
				
				// Uitzondering: eerste ronde zo hoog mogelijk troep meegeven, maar GEEN punten
				if(hand.size() == 13) {
					
					//////std::cout << "Not following pile of first round...\n";
					
					for(unsigned int i = VALUE_ACE;i > VALUE_TWO;i--) {
						int index = FindValueNotColor(&hand,(value)i,COLOR_HEARTS);
						if(index != -1 && index != sqindex) {
							//////std::cout << "Passing highest possible zero points card...\n";
						
							MoveIndexToStapel(stapel,&hand,index);
							return;
						}
					}
				}

				
				// We hebben deze kleur niet, probeer queen of spades weg te doen
				if(sqindex != -1) {
					
					//////std::cout << "Passing queen of spades...\n";
					
					MoveIndexToStapel(stapel,&hand,sqindex);
					return;
				}
				
				// Of gooi zo hoog mogelijke hearts weg...
				for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
					int index = FindValueColor(&hand,(value)i,COLOR_HEARTS);
					if(index != -1) {
						
						//////std::cout << "Passing highest hearts card...\n";
						
						MoveIndexToStapel(stapel,&hand,index);
						
						return;
					}
				}
				
				// Of probeer diamonds leeg te spelen
				if(CountColor(&hand,COLOR_DIAMONDS) < 3) {
					for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
						int index = FindValueColor(&hand,(value)i,COLOR_DIAMONDS);
						if(index != -1) {
							
							//////std::cout << "Passing diamond to empty color...\n";
							
							MoveIndexToStapel(stapel,&hand,index);
							
							return;
						}
					}
				}
				
				// Of probeer clubs leeg te spelen
				if(CountColor(&hand,COLOR_CLUBS) < 3) {
					for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
						int index = FindValueColor(&hand,(value)i,COLOR_CLUBS);
						if(index != -1) {
							
							//////std::cout << "Passing club to empty color...\n";
							
							MoveIndexToStapel(stapel,&hand,index);
							
							return;
						}
					}
				}
				
				// Of gooi zo hoog mogelijke andere kaart weg...
				for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
					int index = FindValueNotColor(&hand,(value)i,COLOR_HEARTS);
					if(index != -1) {
						
						//////std::cout << "Passing highest other card...\n";
						
						MoveIndexToStapel(stapel,&hand,index);
						
						return;
					}
				}
			}
		}
	}
}

void jcmes::storeTrick(Trick* stapel) {
	if(stapel) {
				
		// Houd bij wat er allemaal gespeeld is
		for(unsigned int i = 0;i < stapel->cards().size();i++){
			playedcards.push_back(stapel->cards().at(i));
		}
		
		// Kijk of we al met harten mogen beginnen
		if(!heartsbroken) {
			if(FindFirstColor(&playedcards,COLOR_HEARTS) != -1) {
				heartsbroken = true;
			}
		}
		
		// En sla score op als de zooi naar ons toegaat
		if(stapel->winningPlayer() == playedcardindex) {

			//////std::cout << "\n\nWon cards (" << stapel->penalty() << " points):\n";
			for(unsigned int i = 0;i < stapel->cards().size();i++) {
				PrintKaart(stapel->cards().at(i));
			}
				
			totalscore += stapel->penalty();
		}
		
		if(stapel->penalty() > 0 && stapel->winningPlayer() == playedcardindex) {
			Next(true);
		} else {
			Next(false);
		}
	}
}

int jcmes::getScore(void) {
	return totalscore;
}

////////////////////////////////////////////////////////////////////////////////
/*
	Utils
*/
int jcmes::CountColorBelowValue(std::vector<Card*>* stapel,value valuein,color colorin) {
	int count = 0;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->color() == colorin && stapel->at(i)->value() < valuein) {
				count++;
			}
		}
	}
	return count;
}

int jcmes::CountColor(std::vector<Card*>* stapel,color colorin) {
	int count = 0;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->color() == colorin) {
				count++;
			}
		}
	}
	return count;
}

int jcmes::ExchangeCard(std::vector<Card*>* to,std::vector<Card*>* from,int index) {
	if(index != -1) {
		PrintKaart(from->at(index));
		
		to->push_back(from->at(index));
		from->erase(from->begin() + index);
		return 1;
	}
	
	return 0;
}

bool jcmes::MoveIndexToStapel(Trick* stapel,std::vector<Card*>* hand,int index) {
	if(index < (int)hand->size() && index >= 0) {
		PrintKaart(hand->at(index));
		
		stapel->addCard(hand->at(index));
		hand->erase(hand->begin() + index); // 0 based!
		return true;
	} else {
		return false;
	}
}

int jcmes::FindFirstColor(std::vector<Card*>* stapel,color colorin) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->color() == colorin) {
				return i;
			}
		}
	}
	return -1;
}

int jcmes::FindFirstNotColor(std::vector<Card*>* stapel,color colorin) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->color() != colorin) {
				return i;
			}
		}
	}
	return -1;
}

int jcmes::FindFirstValue(std::vector<Card*>* stapel,value valuein) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() == valuein) {
				return i;
			}
		}
	}
	return -1;
}

int jcmes::FindFirstNotValue(std::vector<Card*>* stapel,value valuein) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() != valuein) {
				return i;
			}
		}
	}
	return -1;
}

int jcmes::FindMaxValue(std::vector<Card*>* stapel) {
	int maxvalueindex = -1;
	int maxvalue = 0;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() > maxvalue) {
				maxvalueindex = i;
				maxvalue = stapel->at(i)->value();
			}
		}
	}
	return maxvalueindex;
}

int jcmes::FindMinValue(std::vector<Card*>* stapel) {
	int maxvalueindex = -1;
	int maxvalue = 0xFFFFFFFF;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() < maxvalue) {
				maxvalueindex = i;
				maxvalue = stapel->at(i)->value();
			}
		}
	}
	return maxvalueindex;
}

int jcmes::FindValueColor(std::vector<Card*>* stapel,value valuein,color colorin) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() == valuein && stapel->at(i)->color() == colorin) {
				return i;
			}
		}
	}
	return -1;
}

int jcmes::FindValueNotColor(std::vector<Card*>* stapel,value valuein,color colorin) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() == valuein && stapel->at(i)->color() != colorin) {
				return i;
			}
		}
	}
	return -1;
}

int jcmes::FindValueNot2Color(std::vector<Card*>* stapel,value valuein,color colorin1,color colorin2) {
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->value() == valuein && stapel->at(i)->color() != colorin1 && stapel->at(i)->color() != colorin2) {
				return i;
			}
		}
	}
	return -1;
}

value jcmes::GetMaxValue(std::vector<Card*>* stapel) {
	value result = VALUE_TWO;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			result = max(result,stapel->at(i)->value());
		}
	}
	return result;
}

value jcmes::GetMaxValueOfColor(std::vector<Card*>* stapel,color colorin) {
	value result = VALUE_TWO;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->color() == colorin) {
				result = max(result,stapel->at(i)->value());
			}
		}
	}
	return result;
}

value jcmes::GetMinValue(std::vector<Card*>* stapel) {
	value result = VALUE_ACE;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			result = min(result,stapel->at(i)->value());
		}
	}
	return result;
}

value jcmes::GetMinValueOfColor(std::vector<Card*>* stapel,color colorin) {
	value result = VALUE_ACE;
	if(stapel) {
		for(unsigned int i = 0;i < stapel->size();i++) {
			if(stapel->at(i)->color() == colorin) {
				result = min(result,stapel->at(i)->value());
			}
		}
	}
	return result;
}

bool jcmes::PassHighestColor(Trick* stapel,color colorin) {
	for(unsigned int i = VALUE_ACE;i >= VALUE_TWO;i--) {
		int index = FindValueColor(&hand,(value)i,colorin);
		if(index != -1) {
			
			//////std::cout << "Passing highest allowed card...\n";

			MoveIndexToStapel(stapel,&hand,index);
			return true;
		}
	}
	return false;
}

bool jcmes::PassLowestColor(Trick* stapel,color colorin) {
	for(unsigned int i = VALUE_TWO;i <= VALUE_ACE;i++) {
		int index = FindValueColor(&hand,(value)i,colorin);
		if(index != -1) {
			
			//////std::cout << "Passing lowest allowed card...\n";

			MoveIndexToStapel(stapel,&hand,index);
			return true;
		}
	}
	return false;
}

bool jcmes::ProcessFirstCardPriority(Trick* stapel) {
	bool cardpassed = false;
	while(!colorlist.empty()) {
		if(!cardpassed) {
			cardpassed = PassLowestColor(stapel,colorlist.top().thiscolor);
		}
		colorlist.pop();
	}
	return cardpassed;
}

////////////////////////////////////////////////////////////////////////////////
/*
	Printing helpers
*/
void jcmes::PrintKaart(Card* kaart) {
	//////std::cout << "    " << kaart->value() << " of " << kaart->color() << ": " << (int)kaart->value() << "\n";
}

void jcmes::Next(bool pause) {
//	if(pause) {
//		cin.ignore();
//	}
	
//	system("cls");
}
	
