#include <stdlib.h>
#include <string.h>

#include <iostream>
#include <vector>

#include "deck.h"
#include "card.h"
#include "player.h"

using namespace std;

static inline unsigned randInt(unsigned upperbound) {
	return (rand() % upperbound);
}

Deck::Deck() {
	unsigned i;
	Color color;
	Value value;
	
	#ifdef DEBUG
	clog << "LOG: Er wordt een nieuw deck aangemaakt." << endl;
	#endif
	
	color = COLOR_CLUBS;
	value = VALUE_TWO;
	for (i = 0; i < NUM_OF_CARDS; i++) {
		d_deck[i].setColor(color);
		d_deck[i].setValue(value);
		
		if ((int) value == 12 && (int) color == 1) {
			d_deck[i].setPenalty((double) 13);
		} else if((int)color == 3){
			d_deck[i].setPenalty((double) 1);
		} else {
			d_deck[i].setPenalty(0);
		}
		
		if (value == VALUE_ACE) {
			color++;
			value = VALUE_TWO;
		} else {
			value++;
		}
	}
}

void Deck::dealCards(Player *players[NUM_OF_PLAYERS]) {
	bool card_dealed[NUM_OF_CARDS];
	unsigned i, rindex;
	vector<Card *> hand;
	
	memset(card_dealed, 0, sizeof(card_dealed));
	
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		hand.clear();
		
		while (hand.size() < NUM_OF_CARDS_PER_PLAYER) {
			while (card_dealed[rindex = randInt(NUM_OF_CARDS)]);
			card_dealed[rindex] = true;
			
			hand.push_back(&d_deck[rindex]);
			
			#ifdef DEBUG
			clog << "LOG: Speler " << i << " krijgt kaart " << d_deck[rindex];
			#endif
		}
		
		players[i]->receiveCards(&hand);
	}
}
