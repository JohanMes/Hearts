#include <iostream>
#include <vector>

#include "trick.h"
#include "card.h"
#include "hearts.h"

using namespace std;

Trick::Trick(int startplayer) {
	d_start_player = startplayer;
	d_penalty = 0;
	
	#ifdef DEBUG
	clog << "LOG: Een nieuwe trick met startspeler " << startplayer << " wordt aangemaakt." << endl;
	#endif
}

Trick::~Trick() {
	return; // TODO?
}

void Trick::addCard(Card *card) {
	#ifdef DEBUG
	clog << "LOG: De kaart (" << card->color() << ", " << card->value() << ") wordt toegevoegd." << endl;
	#endif
	
	if (d_cards.size() == 0) {
		#ifdef DEBUG
		clog << "LOG: Dit is de eerste kaart. De kleur van deze trick wordt gezet." << endl;
		#endif
		
		d_color = card->color();
	}
	
	d_cards.push_back(card);
	d_penalty += card->penalty();
}

void Trick::setColor(Color color) {
	// This is done by addCard.
	return;
}

int Trick::startPlayer() {
	return d_start_player;
}

int Trick::winningPlayer() {
	unsigned i, maxindex;
	Value maxvalue;
	
	#ifdef DEBUG
	clog << "LOG: De winnende speler van deze slag wordt bepaald." << endl;
	#endif
	
	if (d_cards.size() != NUM_OF_PLAYERS) {
		// The trick has not been finished yet.
		#ifdef DEBUG
		clog << "LOG: De winnende speler bestaat nog niet, want de slag is nog niet afgelopen (kaarten gespeeld: " << d_cards.size() << ")." << endl;
		#endif
		
		return -1;
	}
	
	maxvalue = VALUE_TWO;
	// maxindex doesn't have to be set, because the code inside the if-statement will be called at least for i == 0.
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		#ifdef DEBUG
		clog << "LOG: Speler " << ((d_start_player + i) % NUM_OF_PLAYERS) << " gooide deze kaart op: " << *d_cards[i];
		#endif
		
		if (d_cards[i]->color() == d_color && d_cards[i]->value() >= maxvalue) {
			maxindex = i;
			maxvalue = d_cards[i]->value();
		}
	}
	
	#ifdef DEBUG
	clog << "LOG: Speler " << ((d_start_player + maxindex) % NUM_OF_PLAYERS) << " met index " << maxindex << " is de winnaar." << endl;
	#endif
	
	//return ((d_start_player + maxindex) % NUM_OF_PLAYERS);
	return maxindex;
}

vector<Card *> Trick::cards() {
	return d_cards;
}

Color Trick::color() {
	return d_color;
}

int Trick::penalty() {
	return d_penalty;
}
