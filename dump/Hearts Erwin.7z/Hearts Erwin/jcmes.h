#ifndef JOHAN_H_INCLUDED
#define JOHAN_H_INCLUDED

#include <queue>

#include "card.h"
#include "trick.h"
#include "player.h"
#include "hearts.h"
#include "deck.h"

struct PreferColor {
	color thiscolor; // deze kleur
	int enemycount; // aantal enemy
	int lowestvalue;
};

class PreferColorCompare {
	public:
		bool operator() (const PreferColor& lhs, const PreferColor&rhs) const {
			if(lhs.enemycount == rhs.enemycount) {
				return (lhs.lowestvalue > rhs.lowestvalue);
			} else {
				return (lhs.enemycount < rhs.enemycount);
			}
		}
};

class jcmes : public Player {
	protected:
		// Nieuw
		std::vector<Card*> hand;
		std::vector<Card*> playedcards;
		
		std::priority_queue<PreferColor, std::vector<PreferColor>, PreferColorCompare> colorlist;
		
		int totalscore;
		bool heartsbroken;
		bool beginwithtwoofclubs;
		
		int playedcardindex;
		
		// Inherited
		int d_player_id;
	public:
		
		// Kaarten doorgeven
		int ExchangeCard(std::vector<Card*>* to,std::vector<Card*>* from,int index);
		bool MoveIndexToStapel(Trick* stapel,std::vector<Card*>* hand,int index);
		
		// Van alles en nog wat vinden
		int FindFirstColor(std::vector<Card*>* stapel,color colorin);
		int FindFirstNotColor(std::vector<Card*>* stapel,color colorin);
		int FindFirstValue(std::vector<Card*>* stapel,value valuein);
		int FindFirstNotValue(std::vector<Card*>* stapel,value valuein);
		int FindValueColor(std::vector<Card*>* stapel,value valuein,color colorin);
		int FindValueNotColor(std::vector<Card*>* stapel,value valuein,color colorin);
		int FindValueNot2Color(std::vector<Card*>* stapel,value valuein,color colorin1,color colorin2);
		
		int FindMaxValue(std::vector<Card*>* stapel);
		int FindMinValue(std::vector<Card*>* stapel);
		
		int CountColor(std::vector<Card*>* stapel,color colorin);
		int CountColorBelowValue(std::vector<Card*>* stapel,value valuein,color colorin);
		
		value GetMaxValue(std::vector<Card*>* stapel);
		value GetMinValue(std::vector<Card*>* stapel);
		value GetMaxValueOfColor(std::vector<Card*>* stapel,color colorin);
		value GetMinValueOfColor(std::vector<Card*>* stapel,color colorin);
		
		bool PassHighestColor(Trick* stapel,color colorin);
		bool PassLowestColor(Trick* stapel,color colorin);
		
		bool ProcessFirstCardPriority(Trick* stapel);
		
		// Printing helpers
		void PrintKaart(Card* kaart);
		void Next(bool pause);
		
		// Inherited
		void setPlayerId(int);
		int receiveCards(std::vector<Card*>*);
		std::vector<Card*>* passThreeCards(void);
		int receiveThreeCards(std::vector<Card*>*);
		bool hasTwoOfClubs(void);
		void playCard(Trick*);
		void storeTrick(Trick*);
		int getScore(void);
};

#endif /* JOHAN_H_INCLUDED */

