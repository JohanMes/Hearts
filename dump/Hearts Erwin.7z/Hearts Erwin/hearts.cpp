#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <iostream>
#include <vector>

#include "hearts.h"
#include "deck.h"
#include "player.h"
#include "card.h"

using namespace std;

void Hearts::passThreeCards(int round_num) {
	unsigned i;
	vector<Card *> *buf;
	
	#ifdef DEBUG
	clog << "LOG: Laat de spelers 3 kaarten doorgeven (ronde nummer " << round_num << ")." << endl;
	#endif
	
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		buf = d_players[i]->passThreeCards();
		d_players[(i + round_num) % NUM_OF_PLAYERS]->receiveThreeCards(buf);
		delete buf;
	}
}

bool Hearts::playRound(int teller) {
	int startplayer;
	unsigned i;
	Deck deck;
	
	#ifdef DEBUG
	clog << "LOG: Speel een nieuwe ronde (ronde nummer " << teller << ")." << endl;
	#endif
	
	deck.dealCards(d_players);
	
	passThreeCards(teller);
	
	startplayer = getStartPlayer();
	for (i = 0; i < NUM_OF_CARDS_PER_PLAYER; i++) {
		startplayer = (startplayer + playTrick(startplayer)) % NUM_OF_PLAYERS;
	}
	
	return (getMaxScore() < 100);
}

int Hearts::playTrick(int start_player) {
	unsigned i;
	Trick trick(start_player);
	
	#ifdef DEBUG
	clog << "LOG: Speel een nieuwe trick, startende speler: " << start_player << endl;
	#endif
	
	if (start_player < 0 || start_player >= NUM_OF_PLAYERS) {
		#ifdef DEBUG
		clog << "LOG: start_player id = " << start_player << " is ongeldig." << endl;
		#endif
		return -1;
	}
	
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		d_players[(start_player + i) % NUM_OF_PLAYERS]->playCard(&trick);
	//		cout << (int) ((start_player + i) % NUM_OF_PLAYERS)  << " speelt " << *trick.cards()[trick.cards().size()-1];
	}
	
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		d_players[i]->storeTrick(&trick);
		#ifdef DEBUG
		clog << "LOG: Einde slag. Speler " << i << " heeft " << d_players[i]->getScore() << " punten." << endl;
		#endif
	}
	
	return trick.winningPlayer();
}

int Hearts::getStartPlayer() {
	unsigned i;
	
	for (i = 0; i < NUM_OF_PLAYERS && d_players[i]->hasTwoOfClubs() == false; i++);
	#ifdef DEBUG
	clog << "LOG: Speler " << i << " heeft (clubs, 2), dus die begint." << endl;
	#endif
	
	return i;
}

int Hearts::getMaxScore() {
	int max;
	unsigned i;
	
	#ifdef DEBUG
	clog << "LOG: Bepaal de maximale score." << endl;
	#endif
	
	max = 0;
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		#ifdef DEBUG
		clog << "LOG: Speler " << i << " heeft " << d_players[i]->getScore() << " punten." << endl;
		#endif
		
		if (d_players[i]->getScore() > max) {
			max = d_players[i]->getScore();
		}
	}
	
	#ifdef DEBUG
	clog << "LOG: De hoogste score is " << max << endl;
	#endif
	
	return max;
}

Hearts::Hearts() {
	memset(d_players, 0, sizeof(d_players)); // Set all pointers in d_players to NULL, see playGame.
	
	srand(time(NULL));
	
	#ifdef DEBUG
	clog << "LOG: Nieuw hearts spel wordt aangemaakt." << endl;
	#endif
}

void Hearts::setPlayer(Player *player, int player_id) {
	#ifdef DEBUG
	clog << "LOG: Voeg een nieuwe speler net ID " << player_id << " toe." << endl;
	#endif
	
	if (player_id >= NUM_OF_PLAYERS || player_id < 0) {
		#ifdef DEBUG
		clog << "LOG: ID " << player_id << " is geen geldig id." << endl;
		#endif
		
		return;
	}
	
	d_players[player_id] = player;
	player->setPlayerId(player_id);
}

void Hearts::playGame() {
	unsigned i;
	
	#ifdef DEBUG
	clog << "LOG: Speel het spel..." << endl;
	#endif
	
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		if (d_players[i] == NULL) {
			// Don't start when not all players are set.
			#ifdef DEBUG
			clog << "LOG: Niet alle spelers bestaan. Het spel wordt niet gespeeld." << endl;
			#endif
			return;
		}
	}
	
	i = 0;
	while (playRound(i++));
}

ostream &operator<<(ostream &out, Hearts hearts) {
	unsigned i;
	
	for (i = 0; i < NUM_OF_PLAYERS; i++) {
		out << "Player " << i << ": " << hearts.d_players[i]->getScore();
		if (i != (NUM_OF_PLAYERS - 1)) {
			out << endl;
		}
	}
	
	return out;
}
