/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef OPDRACHT_4_3_PRIVATE_H
#define OPDRACHT_4_3_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"2.1.0.802"
#define VER_MAJOR	2
#define VER_MINOR	1
#define VER_RELEASE	0
#define VER_BUILD	802
#define COMPANY_NAME	"Tijo Spelbots"
#define FILE_VERSION	"2.1.0.802"
#define FILE_DESCRIPTION	"Epic hartenjagen"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"� Tim en Johan"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Hartenjagenbot 2.0"
#define PRODUCT_VERSION	"2.1.0.802"

#endif /*OPDRACHT_4_3_PRIVATE_H*/
